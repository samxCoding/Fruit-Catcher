// Get the canvas and context
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// Set the canvas size
canvas.width = 600;
canvas.height = 400;

// Define game constants
const PLAYER_SPEED = 5;
const BULLET_SPEED = 10;
const ENEMY_SPEED = 2;
const ENEMY_SPAWN_INTERVAL = 1500;

// Initialize game variables
let player;
let bullets = [];
let enemies = [];
let enemySpawnTimeout;
let score = 0;
let isGameOver = false;

// Define the Player class
class Player {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 40;
    this.height = 40;
  }

  // Update the player's position
  update() {
    if (keyState["ArrowLeft"] && this.x > 0) {
      this.x -= PLAYER_SPEED;
    }
    if (keyState["ArrowRight"] && this.x < canvas.width - this.width) {
      this.x += PLAYER_SPEED;
    }
    if (keyState["ArrowUp"] && this.y > 0) {
      this.y -= PLAYER_SPEED;
    }
    if (keyState["ArrowDown"] && this.y < canvas.height - this.height) {
      this.y += PLAYER_SPEED;
    }
  }

  // Draw the player
  draw() {
    ctx.fillStyle = "white";
    ctx.fillRect(this.x, this.y, this.width, this.height);
  }
}

// Define the Bullet class
class Bullet {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 10;
    this.height = 20;
  }

  // Update the bullet's position
  update() {
    this.y -= BULLET_SPEED;
  }

  // Draw the bullet
  draw() {
    ctx.fillStyle = "red";
    ctx.fillRect(this.x, this.y, this.width, this.height);
  }
}

// Define the Enemy class
class Enemy {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.width = 40;
    this.height = 40;
  }

  // Update the enemy's position
  update() {
    this.y += ENEMY_SPEED;
  }

  // Draw the enemy
  draw() {
    ctx.fillStyle = "green";
    ctx.fillRect(this.x, this.y, this.width, this.height);
  }
}

// Initialize the key state object
const keyState = {};

// Add event listeners to track key presses and releases
document.addEventListener("keydown", function(event) {
  keyState[event.code] = true;
});

document.addEventListener("keyup", function(event) {
  keyState[event.code] = false;
});

// Spawn a new enemy
function spawnEnemy() {
  const x = Math.random() * (canvas.width - 40);
  const y = -40;
  enemies.push(new Enemy(x, y));
  enemySpawnTimeout = setTimeout(spawnEnemy, ENEMY_SPAWN_INTERVAL);
}

// Update the game state
function update() {
  // Update the player
  player.update();

  // Update the bullets
  bullets.forEach(function(bullet) {
    bullet.update();
  });

  // Update the enemies
  enemies.forEach(function(enemy) {
    enemy.update();
  });

  // Check for collisions
  bullets.forEach(function(bullet) {
    enemies.forEach(function(enemy, index) {
      if (collides(bullet, enemy)) {
        // Remove the bullet and enemy
